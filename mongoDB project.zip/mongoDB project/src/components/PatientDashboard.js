import React, { useEffect, useState } from "react";
import "./Auth.css";

export default function PatientDashboard() {
  const [email, setEmail] = useState(""); // use dummy email or retrieve from login context
  const [appointments, setAppointments] = useState([]);
  const [form, setForm] = useState({ doctorName: "", date: "", time: "", reason: "" });
  const [editId, setEditId] = useState(null);

    const [doctors, setDoctors] = useState([]);

    const fetchAppointments = async (email) => {
    const res = await fetch(`http://localhost:5000/api/appointments/${email}`);
    const data = await res.json();
    setAppointments(data);
    };

    useEffect(() => {
    const patientEmail = prompt("Enter your registered email:");
    setEmail(patientEmail);
    fetchAppointments(patientEmail);
    fetchDoctors(); // 👈 NEW
    }, []);

    const fetchDoctors = async () => {
    const res = await fetch("http://localhost:5000/api/doctors");
    const data = await res.json();
    setDoctors(data);
    };



  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = editId
      ? `http://localhost:5000/api/appointments/${editId}`
      : "http://localhost:5000/api/appointments";
    const method = editId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, patientEmail: email }),
    });

    if (res.ok) {
      alert(editId ? "Updated" : "Booked");
      fetchAppointments(email);
      setForm({ doctorName: "", date: "", time: "", reason: "" });
      setEditId(null);
    }
  };

  const handleEdit = (appt) => {
    setForm(appt);
    setEditId(appt._id);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this appointment?")) return;
    await fetch(`http://localhost:5000/api/appointments/${id}`, { method: "DELETE" });
    fetchAppointments(email);
  };

  return (
    <div className="auth-container">
      <h2>Welcome, Patient</h2>
      <form onSubmit={handleSubmit} className="auth-form">
        <select name="doctorName" value={form.doctorName} onChange={handleChange} required>
        <option value="">Select Doctor</option>
        {doctors.map((doc) => (
            <option key={doc._id} value={doc.name}>
            {doc.name}
            </option>
          ))}
        </select>
        <input name="date" type="date" value={form.date} onChange={handleChange} required />
        <input name="time" type="time" value={form.time} onChange={handleChange} required />
        <input name="reason" placeholder="Reason" value={form.reason} onChange={handleChange} required />
        <button type="submit">{editId ? "Update" : "Book"} Appointment</button>
      </form>

      <h3>Your Appointments</h3>
      {appointments.map((appt) => (
        <div key={appt._id} className="appt-card">
          <p><strong>Doctor:</strong> {appt.doctorName}</p>
          <p><strong>Date:</strong> {appt.date}</p>
          <p><strong>Time:</strong> {appt.time}</p>
          <p><strong>Reason:</strong> {appt.reason}</p>
          <button onClick={() => handleEdit(appt)}>Edit</button>
          <button onClick={() => handleDelete(appt._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}
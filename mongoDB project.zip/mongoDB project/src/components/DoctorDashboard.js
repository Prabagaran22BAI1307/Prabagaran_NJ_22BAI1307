// DoctorDashboard.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

export default function DoctorDashboard() {
  const [email, setEmail] = useState("");
  const [appointments, setAppointments] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const doctorEmail = prompt("Enter your email to load appointments:");
    setEmail(doctorEmail);
    fetchAppointments(doctorEmail);
  }, []);

  const fetchAppointments = async (doctorEmail) => {
    try {
      const res = await fetch(`http://localhost:5000/api/doctor-appointments/${doctorEmail}`);
      const data = await res.json();
      setAppointments(data);
    } catch (err) {
      console.error("Failed to fetch appointments:", err);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Doctor Dashboard</h2>
      <h4>Appointments for Dr. {email}</h4>
      {appointments.length === 0 ? (
        <p>No appointments found</p>
      ) : (
        <table border="1" cellPadding={10}>
          <thead>
            <tr>
              <th>Patient</th>
              <th>Date</th>
              <th>Time</th>
              <th>Reason</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((appt) => (
              <tr key={appt._id}>
                <td>{appt.patientEmail}</td>
                <td>{appt.date}</td>
                <td>{appt.time}</td>
                <td>{appt.reason}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
import React from "react";
import { Link } from "react-router-dom";
import "./Auth.css";

export default function Home() {
  return (
    <div className="auth-container">
      <h1>🏥 Hospital Management System</h1>
      <div className="home-buttons">
        <Link to="/patient/register">
          <button>Patient Register</button>
        </Link>
        <Link to="/patient/login">
          <button>Patient Login</button>
        </Link>
        <Link to="/doctor/login">
          <button>Doctor Login</button>
        </Link>
      </div>
    </div>
  );
}